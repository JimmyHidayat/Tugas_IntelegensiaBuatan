import java.util.*;

public class TravelPlanner {
    private static Map<String, List<String>> cityRoutes = new HashMap<>();
    private static Map<String, Map<String, Integer>> cityDistances = new HashMap<>();
    private static Map<String, String> previousCities = new HashMap<>(); // Tambahkan variabel ini

    public static void main(String[] args) {
        initializeCityDistances();
        Scanner scanner = new Scanner(System.in);

        System.out.println("Selamat datang di Travel Planner!");

        while (true) {
            System.out.println("Pilih kota asal:");
            String sourceCity = scanner.nextLine();
            System.out.println("Pilih kota tujuan:");
            String destinationCity = scanner.nextLine();

            if (cityDistances.containsKey(sourceCity) && cityDistances.containsKey(destinationCity)) {
                int shortestDistance = findShortestDistance(sourceCity, destinationCity);
                System.out.println("Jarak terpendek: " + shortestDistance + " km");

                List<String> shortestRoute = findShortestRoute(sourceCity, destinationCity);
                System.out.println("Rute terpendek: " + shortestRoute);

                int alternateDistance = findAlternateDistance(sourceCity, destinationCity);
                System.out.println("Jarak jalur alternatif: " + alternateDistance + " km");
            } else {
                System.out.println("Kota tidak valid. Coba lagi.");
            }

            System.out.println("Apakah Anda ingin mencoba lagi? (y/n)");
            String input = scanner.nextLine();
            if (!input.equalsIgnoreCase("y")) {
                break;
            }
        }
    }

    private static void initializeCityDistances() {
        // Inisialisasi data jarak antar kota (dalam kilometer)
        addCity("Jakarta", "Bandung", 140);
        addCity("Jakarta", "Surabaya", 700);
        addCity("Bandung", "Surabaya", 600);
        addCity("Jakarta", "Yogyakarta", 500);
        addCity("Surabaya", "Yogyakarta", 400);
        addCity("Bandung", "Yogyakarta", 350);
        // Tambahkan data jarak dan kota lainnya sesuai kebutuhan
    }

    private static void addCity(String sourceCity, String destinationCity, int distance) {
        cityDistances.computeIfAbsent(sourceCity, k -> new HashMap<>()).put(destinationCity, distance);
        cityDistances.computeIfAbsent(destinationCity, k -> new HashMap<>()).put(sourceCity, distance);
    }

    private static int findShortestDistance(String sourceCity, String destinationCity) {
        Map<String, Integer> distances = new HashMap<>();
        Set<String> unvisitedCities = new HashSet<>(cityDistances.keySet());

        for (String city : cityDistances.keySet()) {
            distances.put(city, Integer.MAX_VALUE);
        }
        distances.put(sourceCity, 0);

        while (!unvisitedCities.isEmpty()) {
            String currentCity = getClosestCity(distances, unvisitedCities);
            unvisitedCities.remove(currentCity);

            for (String neighbor : cityDistances.get(currentCity).keySet()) {
                int distanceToNeighbor = distances.get(currentCity) + cityDistances.get(currentCity).get(neighbor);
                if (distanceToNeighbor < distances.get(neighbor)) {
                    distances.put(neighbor, distanceToNeighbor);
                    previousCities.put(neighbor, currentCity);
                }
            }
        }

        return distances.get(destinationCity);
    }

    private static String getClosestCity(Map<String, Integer> distances, Set<String> unvisitedCities) {
        String closestCity = null;
        int minDistance = Integer.MAX_VALUE;

        for (String city : unvisitedCities) {
            if (distances.get(city) < minDistance) {
                minDistance = distances.get(city);
                closestCity = city;
            }
        }

        return closestCity;
    }

    private static List<String> findShortestRoute(String sourceCity, String destinationCity) {
        List<String> shortestRoute = new ArrayList<>();
        String currentCity = destinationCity;

        while (currentCity != null) {
            shortestRoute.add(currentCity);
            currentCity = previousCities.get(currentCity);
        }

        Collections.reverse(shortestRoute);
        return shortestRoute;
    }

    private static int findAlternateDistance(String sourceCity, String destinationCity) {
        List<String> alternateRoute = findAlternateRoute(sourceCity, destinationCity);
        int alternateDistance = calculateRouteDistance(alternateRoute);

        return alternateDistance;
    }

    private static List<String> findAlternateRoute(String sourceCity, String destinationCity) {
        // Implementasi logika untuk mencari jalur alternatif
        List<String> alternateRoute = new ArrayList<>();
        String currentCity = sourceCity;

        while (!currentCity.equals(destinationCity)) {
            String nextCity = findNextAlternateCity(currentCity, destinationCity);
            alternateRoute.add(nextCity);
            currentCity = nextCity;
        }

        return alternateRoute;
    }

    private static String findNextAlternateCity(String currentCity, String destinationCity) {
        Set<String> unvisitedCities = new HashSet<>(cityDistances.get(currentCity).keySet());
        unvisitedCities.remove(destinationCity);

        if (unvisitedCities.isEmpty()) {
            return destinationCity;
        }

        int minDistance = Integer.MAX_VALUE;
        String nextCity = null;

        for (String city : unvisitedCities) {
            int distanceToDestination = cityDistances.get(city).get(destinationCity);
            if (distanceToDestination < minDistance) {
                minDistance = distanceToDestination;
                nextCity = city;
            }
        }

        return nextCity;
    }

    private static int calculateRouteDistance(List<String> route) {
        int distance = 0;

        for (int i = 0; i < route.size() - 1; i++) {
            String currentCity = route.get(i);
            String nextCity = route.get(i + 1);
            distance += cityDistances.get(currentCity).get(nextCity);
        }

        return distance;
    }
}
